﻿// Add the namespace of your new communicator class if needed
// using Controller.Communication; 
using Controller.Common;
using Controller.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Controller.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        // Collections for UI binding
        public ObservableCollection<NodeViewModel> Nodes { get; } = new ObservableCollection<NodeViewModel>();
        public ObservableCollection<EdgeViewModel> Edges { get; } = new ObservableCollection<EdgeViewModel>();
        public ObservableCollection<LogEntryViewModel> LogEntries { get; } = new ObservableCollection<LogEntryViewModel>();

        // Status properties
        private string _connectionStatus = "Disconnected";
        public string ConnectionStatus { get => _connectionStatus; set { _connectionStatus = value; OnPropertyChanged(); } }

        private NodeViewModel? _selectedTargetNode;
        public NodeViewModel? SelectedTargetNode { get => _selectedTargetNode; set { _selectedTargetNode = value; OnPropertyChanged(); } }

        private BitmapImage? _liveVideoFrame;
        public BitmapImage? LiveVideoFrame { get => _liveVideoFrame; set { _liveVideoFrame = value; OnPropertyChanged(); } }

        // Setup Mode Properties
        public ObservableCollection<Point> PerspectivePoints { get; } = new ObservableCollection<Point>();
        private bool _isInCalibrationMode;
        public bool IsInCalibrationMode { get => _isInCalibrationMode; set { _isInCalibrationMode = value; OnPropertyChanged(); OnPropertyChanged(nameof(IsInSetupMode)); } }

        private bool _isInPerspectiveSetupMode;
        public bool IsInPerspectiveSetupMode { get => _isInPerspectiveSetupMode; set { _isInPerspectiveSetupMode = value; OnPropertyChanged(); OnPropertyChanged(nameof(IsInSetupMode)); } }

        public bool IsInSetupMode => IsInCalibrationMode || IsInPerspectiveSetupMode;
        public string PerspectiveSetupInstructions => $"Click {4 - PerspectivePoints.Count} more point(s) on the video feed.";

        // Commands
        public ICommand StartExplorationCommand { get; }
        public ICommand EmergencyStopCommand { get; }
        public ICommand ResetMapCommand { get; }
        public ICommand StartCalibrationCommand { get; }
        public ICommand CaptureCalibrationImageCommand { get; }
        public ICommand FinishCalibrationCommand { get; }
        public ICommand StartPerspectiveSetupCommand { get; }
        public ICommand FinishPerspectiveSetupCommand { get; }
        public ICommand CancelSetupCommand { get; }

        private bool _isLedOn;
        public bool IsLedOn
        {
            get => _isLedOn;
            set
            {
                if (_isLedOn != value)
                {
                    _isLedOn = value;
                    OnPropertyChanged();
                    _ = _communicator.SendCommandAsync("toggle_led", new { state = _isLedOn });
                }
            }
        }

        private readonly object _lock = new object();

        // Use the dedicated communicator service for all network operations
        private readonly PythonCommunicator _communicator;

        public MainWindowViewModel()
        {
            // 1. Initialize the communicator service
            _communicator = new PythonCommunicator();

            // 2. Subscribe to its events to receive data and log messages
            _communicator.OnDataReceived += ProcessIncomingData;
            _communicator.OnLogMessage += AddLogEntry; // Log messages from the communicator

            // 3. Start the communication service
            _ = _communicator.ConnectAsync();

            // 4. All commands now use the communicator's SendCommandAsync method
            StartExplorationCommand = new RelayCommand(async _ => await _communicator.SendCommandAsync("start_exploration"));
            EmergencyStopCommand = new RelayCommand(async _ => await _communicator.SendCommandAsync("emergency_stop"));
            ResetMapCommand = new RelayCommand(async _ => await _communicator.SendCommandAsync("reset_map"));

            StartCalibrationCommand = new RelayCommand(async _ => {
                await _communicator.SendCommandAsync("start_calibration");
                IsInCalibrationMode = true;
            });
            CaptureCalibrationImageCommand = new RelayCommand(async _ => await _communicator.SendCommandAsync("capture_calib_image"));
            FinishCalibrationCommand = new RelayCommand(async _ => {
                await _communicator.SendCommandAsync("finish_calib");
                IsInCalibrationMode = false;
            });

            StartPerspectiveSetupCommand = new RelayCommand(async _ => {
                await _communicator.SendCommandAsync("start_perspective_setup");
                PerspectivePoints.Clear();
                IsInPerspectiveSetupMode = true;
                OnPropertyChanged(nameof(PerspectiveSetupInstructions));
            });

            FinishPerspectiveSetupCommand = new RelayCommand(
                async _ => {
                    await _communicator.SendCommandAsync("finish_perspective");
                    IsInPerspectiveSetupMode = false;
                },
                _ => PerspectivePoints.Count == 4
            );

            CancelSetupCommand = new RelayCommand(async _ => {
                // Using "cancel_calib" or "cancel_perspective" might be better
                // depending on Python implementation. "cancel_setup" is a general name.
                await _communicator.SendCommandAsync("cancel_setup");
                IsInCalibrationMode = false;
                IsInPerspectiveSetupMode = false;
            });
        }

        public void HandleImageClick(Point clickPos, double actualWidth, double actualHeight)
        {
            if (!IsInPerspectiveSetupMode || PerspectivePoints.Count >= 4) return;
            if (actualWidth == 0 || actualHeight == 0) return;

            double originalWidth = 640;
            double originalHeight = 480;

            double scaledX = (clickPos.X / actualWidth) * originalWidth;
            double scaledY = (clickPos.Y / actualHeight) * originalHeight;

            PerspectivePoints.Add(clickPos);
            var scaledPointPayload = new { x = scaledX, y = scaledY };

            // Use the communicator to send the point
            _ = _communicator.SendCommandAsync("perspective_point_clicked", scaledPointPayload);

            OnPropertyChanged(nameof(PerspectiveSetupInstructions));
            CommandManager.InvalidateRequerySuggested();
        }

        private void ProcessIncomingData(string jsonData)
        {
            try
            {
                var pythonData = JsonConvert.DeserializeObject<PythonData>(jsonData);
                if (pythonData == null) return;

                Application.Current.Dispatcher.Invoke(() =>
                {
                    lock (_lock)
                    {
                        if (!string.IsNullOrEmpty(pythonData.Log)) AddLogEntry(pythonData.Log);
                        if (!string.IsNullOrEmpty(pythonData.Image)) UpdateVideoFrame(pythonData.Image);

                        UpdateStatus(pythonData.IsConnected ? "✅ Connected to Python Server" : "❌ Disconnected");

                        var existingNodeIds = new HashSet<string>(Nodes.Select(n => n.Id));
                        foreach (var pyNode in pythonData.Nodes)
                        {
                            if (!existingNodeIds.Contains(pyNode.Id))
                            {
                                // Node positions might need better logic than this in the future
                                var newNode = new NodeViewModel(pyNode.Id, this)
                                {
                                    X = (pyNode.Id.Length * 50) % 300 + 50,
                                    Y = (pyNode.Id.Length * 70) % 200 + 50
                                };
                                Nodes.Add(newNode);
                            }
                        }

                        Edges.Clear();
                        foreach (var pyEdge in pythonData.Edges)
                        {
                            var fromNode = Nodes.FirstOrDefault(n => n.Id == pyEdge.From);
                            var toNode = Nodes.FirstOrDefault(n => n.Id == pyEdge.To);
                            if (fromNode != null && toNode != null)
                            {
                                Edges.Add(new EdgeViewModel
                                {
                                    StartPoint = new Point(fromNode.X, fromNode.Y),
                                    EndPoint = new Point(toNode.X, toNode.Y),
                                    StartNodeId = fromNode.Id,
                                    EndNodeId = toNode.Id
                                });
                            }
                        }

                        UpdateNodeColors(pythonData.CurrentNode);
                        UpdateEdgeColors(pythonData.NavigationPath);
                    }
                });
            }
            catch (Exception ex)
            {
                AddLogEntry($"⚠️ ERROR processing data: {ex.Message}");
            }
        }

        private void UpdateVideoFrame(string base64Image)
        {
            try
            {
                byte[] imageBytes = Convert.FromBase64String(base64Image);
                using (var ms = new MemoryStream(imageBytes))
                {
                    var frame = new BitmapImage();
                    frame.BeginInit();
                    frame.CacheOption = BitmapCacheOption.OnLoad;
                    frame.StreamSource = ms;
                    frame.EndInit();
                    frame.Freeze(); // Important for performance in WPF
                    LiveVideoFrame = frame;
                }
            }
            catch (Exception ex)
            {
                AddLogEntry($"⚠️ Image decoding failed: {ex.Message}");
            }
        }

        private void UpdateEdgeColors(List<string> path)
        {
            foreach (var edge in Edges)
            {
                edge.StrokeColor = Brushes.Gray;
                edge.StrokeThickness = 2;
            }

            if (path == null || path.Count < 2) return;

            for (int i = 0; i < path.Count - 1; i++)
            {
                string fromId = path[i];
                string toId = path[i + 1];
                var edgeToHighlight = Edges.FirstOrDefault(e => (e.StartNodeId == fromId && e.EndNodeId == toId) || (e.StartNodeId == toId && e.EndNodeId == fromId));
                if (edgeToHighlight != null)
                {
                    edgeToHighlight.StrokeColor = Brushes.LawnGreen;
                    edgeToHighlight.StrokeThickness = 4;
                }
            }
        }

        private void UpdateNodeColors(string? currentNodeId)
        {
            foreach (var node in Nodes)
            {
                if (node.Id == currentNodeId) node.FillColor = Brushes.Red;
                else if (node == SelectedTargetNode) node.FillColor = Brushes.Yellow;
                else node.FillColor = Brushes.CornflowerBlue;
            }
        }

        public void SelectNodeAsTarget(NodeViewModel node)
        {
            lock (_lock)
            {
                SelectedTargetNode = node;
                UpdateNodeColors(null); // You might want to pass the current robot node here
                AddLogEntry($"✅ Target set to Node: {node.Id}");
                var payload = new { target_node = node.Id };
                _ = _communicator.SendCommandAsync("set_target", payload);
            }
        }

        private void AddLogEntry(string message)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                if (LogEntries.Count > 200) LogEntries.RemoveAt(0);
                LogEntries.Add(new LogEntryViewModel(message));
            });
        }

        private void UpdateStatus(string status)
        {
            ConnectionStatus = status;
        }

        // Call this when the application window closes
        public void Cleanup()
        {
            _communicator.Dispose();
        }
    }
}