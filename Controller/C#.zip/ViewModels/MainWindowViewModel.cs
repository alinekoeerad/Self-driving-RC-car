﻿using Controller.Common;
using Controller.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Controller.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        // Collections for UI binding
        public ObservableCollection<NodeViewModel> Nodes { get; } = new ObservableCollection<NodeViewModel>();
        public ObservableCollection<EdgeViewModel> Edges { get; } = new ObservableCollection<EdgeViewModel>();
        public ObservableCollection<LogEntryViewModel> LogEntries { get; } = new ObservableCollection<LogEntryViewModel>();

        // Status properties
        private string _connectionStatus = "Disconnected";
        public string ConnectionStatus { get => _connectionStatus; set { _connectionStatus = value; OnPropertyChanged(); } }

        private NodeViewModel? _selectedTargetNode;
        public NodeViewModel? SelectedTargetNode { get => _selectedTargetNode; set { _selectedTargetNode = value; OnPropertyChanged(); } }

        private BitmapImage? _liveVideoFrame;
        public BitmapImage? LiveVideoFrame { get => _liveVideoFrame; set { _liveVideoFrame = value; OnPropertyChanged(); } }

        // Commands for the Control Panel
        public ICommand StartExplorationCommand { get; }
        public ICommand EmergencyStopCommand { get; }
        public ICommand ResetMapCommand { get; }
        public ICommand StartCalibrationCommand { get; } // ADDED: Command for calibration

        // ADD NEW COMMANDS
        public ICommand CaptureCalibrationImageCommand { get; }
        public ICommand FinishCalibrationCommand { get; }
        public ICommand CancelCalibrationCommand { get; }
        public ICommand StartPerspectiveSetupCommand { get; } // ADD THIS
    
        // ADD NEW PROPERTY FOR VISIBILITY
        private bool _isInCalibrationMode;
        public bool IsInCalibrationMode
        {
            get => _isInCalibrationMode;
            set { _isInCalibrationMode = value; OnPropertyChanged(); }
        }

        // Property for the LED toggle
        private bool _isLedOn;
        public bool IsLedOn
        {
            get => _isLedOn;
            set
            {
                if (_isLedOn != value)
                {
                    _isLedOn = value;
                    OnPropertyChanged();
                    _ = SendCommandToPython("toggle_led", new { state = _isLedOn });
                }
            }
        }

        private bool _isRunning = true;
        private readonly object _lock = new object();


        public MainWindowViewModel()
        {
            Task.Run(NetworkListenerLoop);
            StartExplorationCommand = new RelayCommand(param => SendCommandToPython("start_exploration"));
            EmergencyStopCommand = new RelayCommand(param => SendCommandToPython("emergency_stop"));
            ResetMapCommand = new RelayCommand(param => SendCommandToPython("reset_map"));

            // ADD THESE LINES
            StartCalibrationCommand = new RelayCommand(param => {
                SendCommandToPython("start_calibration");
                IsInCalibrationMode = true;
            });
            CaptureCalibrationImageCommand = new RelayCommand(param => SendCommandToPython("capture_calib_image"));
            FinishCalibrationCommand = new RelayCommand(param => {
                SendCommandToPython("finish_calib");
                IsInCalibrationMode = false;
            });
            CancelCalibrationCommand = new RelayCommand(param => {
                SendCommandToPython("cancel_calib");
                IsInCalibrationMode = false;
            });

            StartCalibrationCommand = new RelayCommand(param => SendCommandToPython("start_calibration"));
            StartPerspectiveSetupCommand = new RelayCommand(param => SendCommandToPython("start_perspective_setup")); // ADD THIS

        }

        private async Task NetworkListenerLoop()
        {
            while (_isRunning)
            {
                try
                {
                    using (var client = new TcpClient())
                    {
                        UpdateStatus("Connecting to Python server...");
                        await client.ConnectAsync("127.0.0.1", 9998);
                        UpdateStatus("✅ Connected to Python Server");
                        await HandleClientStream(client);
                    }
                }
                catch (Exception)
                {
                    UpdateStatus("❌ Connection failed. Retrying in 5s...");
                    await Task.Delay(5000);
                }
            }
        }

        private async Task HandleClientStream(TcpClient client)
        {
            using NetworkStream stream = client.GetStream();
            byte[] lengthBuffer = new byte[4];
            int bytesRead;

            while (_isRunning && client.Connected)
            {
                try
                {
                    bytesRead = await stream.ReadAsync(lengthBuffer, 0, 4);
                    if (bytesRead < 4) break;

                    if (BitConverter.IsLittleEndian) Array.Reverse(lengthBuffer);
                    int messageLength = BitConverter.ToInt32(lengthBuffer, 0);

                    if (messageLength <= 0 || messageLength > 2 * 1024 * 1024) break;

                    byte[] messageBuffer = new byte[messageLength];
                    int totalBytesRead = 0;
                    while (totalBytesRead < messageLength)
                    {
                        bytesRead = await stream.ReadAsync(messageBuffer, totalBytesRead, messageLength - totalBytesRead);
                        if (bytesRead == 0) break;
                        totalBytesRead += bytesRead;
                    }
                    if (totalBytesRead < messageLength) break;

                    string jsonData = Encoding.UTF8.GetString(messageBuffer);
                    ProcessIncomingData(jsonData);
                }
                catch (IOException) { break; }
                catch (Exception ex)
                {
                    AddLogEntry($"ERROR processing data: {ex.Message}");
                    break;
                }
            }
        }

        private void ProcessIncomingData(string jsonData)
        {
            var pythonData = JsonConvert.DeserializeObject<PythonData>(jsonData);
            if (pythonData == null) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                lock (_lock)
                {
                    if (!string.IsNullOrEmpty(pythonData.Log)) AddLogEntry(pythonData.Log);
                    if (!string.IsNullOrEmpty(pythonData.Image)) UpdateVideoFrame(pythonData.Image);

                    foreach (var pyNode in pythonData.Nodes)
                    {
                        if (Nodes.All(n => n.Id != pyNode.Id))
                        {
                            var newNode = new NodeViewModel(pyNode.Id, this)
                            {
                                X = pyNode.Position[0] * 50 + 100,
                                Y = pyNode.Position[1] * 50 + 100
                            };
                            Nodes.Add(newNode);
                        }
                    }

                    Edges.Clear();
                    foreach (var pyEdge in pythonData.Edges)
                    {
                        var fromNode = Nodes.FirstOrDefault(n => n.Id == pyEdge.From);
                        var toNode = Nodes.FirstOrDefault(n => n.Id == pyEdge.To);
                        if (fromNode != null && toNode != null)
                        {
                            Edges.Add(new EdgeViewModel
                            {
                                StartPoint = new Point(fromNode.X, fromNode.Y),
                                EndPoint = new Point(toNode.X, toNode.Y),
                                StartNodeId = fromNode.Id,
                                EndNodeId = toNode.Id
                            });
                        }
                    }

                    UpdateNodeColors(pythonData.CurrentNode);
                    UpdateEdgeColors(pythonData.NavigationPath);
                }
            });
        }

        private void UpdateVideoFrame(string base64Image)
        {
            try
            {
                byte[] imageBytes = Convert.FromBase64String(base64Image);
                using (var ms = new MemoryStream(imageBytes))
                {
                    var frame = new BitmapImage();
                    frame.BeginInit();
                    frame.CacheOption = BitmapCacheOption.OnLoad;
                    frame.StreamSource = ms;
                    frame.EndInit();
                    frame.Freeze();
                    LiveVideoFrame = frame;
                }
            }
            catch (Exception ex)
            {
                AddLogEntry($"⚠️ Image decoding failed: {ex.Message}");
            }
        }

        private void UpdateEdgeColors(List<string> path)
        {
            foreach (var edge in Edges)
            {
                edge.StrokeColor = Brushes.Gray;
                edge.StrokeThickness = 2;
            }

            if (path == null || path.Count < 2) return;

            for (int i = 0; i < path.Count - 1; i++)
            {
                string fromId = path[i];
                string toId = path[i + 1];

                var edgeToHighlight = Edges.FirstOrDefault(e =>
                    (e.StartNodeId == fromId && e.EndNodeId == toId) ||
                    (e.StartNodeId == toId && e.EndNodeId == fromId)
                );

                if (edgeToHighlight != null)
                {
                    edgeToHighlight.StrokeColor = Brushes.LawnGreen;
                    edgeToHighlight.StrokeThickness = 4;
                }
            }
        }

        private void UpdateNodeColors(string? currentNodeId)
        {
            foreach (var node in Nodes)
            {
                if (node.Id == currentNodeId)
                    node.FillColor = Brushes.Red;
                else if (node == SelectedTargetNode)
                    node.FillColor = Brushes.Yellow;
                else
                    node.FillColor = Brushes.CornflowerBlue;
            }
        }

        public void SelectNodeAsTarget(NodeViewModel node)
        {
            lock (_lock)
            {
                SelectedTargetNode = node;
                UpdateNodeColors(null);
                AddLogEntry($"✅ Target set to Node: {node.Id}");
                var payload = new { target_node = node.Id };
                _ = SendCommandToPython("set_target", payload);
            }
        }

        private async Task SendCommandToPython(string commandType, object? payload = null)
        {
            try
            {
                using (var client = new TcpClient())
                {
                    await client.ConnectAsync("127.0.0.1", 9999);
                    using (var stream = client.GetStream())
                    {
                        var data = new { type = commandType, payload };
                        var jsonData = JsonConvert.SerializeObject(data);
                        var jsonBytes = Encoding.UTF8.GetBytes(jsonData);
                        await stream.WriteAsync(jsonBytes, 0, jsonBytes.Length);
                    }
                }
                AddLogEntry($"✅ Command '{commandType}' sent to server.");
            }
            catch (Exception ex)
            {
                AddLogEntry($"❌ Failed to send command: {ex.Message}");
            }
        }

        private void AddLogEntry(string message)
        {
            if (LogEntries.Count > 200) LogEntries.RemoveAt(0);
            LogEntries.Add(new LogEntryViewModel(message));
        }

        private void UpdateStatus(string status)
        {
            ConnectionStatus = status;
            Application.Current.Dispatcher.Invoke(() => AddLogEntry(status));
        }

        public void Stop()
        {
            _isRunning = false;
        }
    }
}