﻿using Controller.ViewModels;
using System.Windows;

namespace Controller
{
    public partial class MainWindow : Window
    {
        private readonly MainWindowViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();
            // The DataContext is set in XAML, so we can retrieve it here.
            _viewModel = (MainWindowViewModel)DataContext;
            // Ensure the network loop is stopped when the window is closed.
            this.Closing += (s, e) => _viewModel.Stop();
        }
    }
}